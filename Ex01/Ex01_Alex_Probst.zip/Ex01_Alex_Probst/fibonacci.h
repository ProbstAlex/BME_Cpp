#ifndef FIBONACCI_H
#define FIBONACCI_H

int fibonacci(int f, int fprev);
double ratio(int f, int fprev);
double ratioDeviation(double ratio);

#endif // FIBONACCI_H
