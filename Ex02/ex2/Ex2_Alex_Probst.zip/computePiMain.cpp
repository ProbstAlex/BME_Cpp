#include <iostream>
#include "throwdarts.h"

int main ()
{
    std::cout << "******* C++ Programming I - Ex2 - Alex Probst ******* " << std::endl << std::endl;

    ex2();

    return 0;
}
