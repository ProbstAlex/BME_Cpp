#ifndef THROWDARTS_H
#define THROWDARTS_H
#include <random>

void throwManyDarts(std::uniform_real_distribution<double> dist, std::mt19937 mt);
void ex2();


#endif // THROWDARTS_H
